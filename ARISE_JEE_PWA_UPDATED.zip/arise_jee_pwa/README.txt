ARISE — JEE Level Up System (PWA)

WHAT'S INCLUDED
- index.html: the app UI and functionality
- manifest.json: home-screen install details
- sw.js: cache for app shell/offline opening after first visit
- icons/: launcher icons

IMPORTANT LIMITATIONS
1. A standalone/local HTML file works for ordinary app features in a modern browser, but true PWA install and offline caching require a secure HTTPS host.
2. ARISE cannot directly block other apps. Use Android Settings > Digital Wellbeing & parental controls > Focus mode, select YouTube and other distractions, then turn it on or schedule it.
3. Study logs, settings, and missions are stored in browser local storage. Diary photos are stored in browser IndexedDB on this device. They are not uploaded to a server. Clearing browser data or uninstalling/resetting the browser may erase them. Export a JSON backup regularly; the JSON backup does not include diary photos.
4. If publishing with a public static host or repository, upload only these app files. Never upload your diary photos or backup data.

HOW TO INSTALL ON ANDROID (FREE)
This package must be hosted over HTTPS for full PWA installation. One free route is GitHub Pages:
1. Create a repository for the app source.
2. Upload the CONTENTS of this folder (index.html, manifest.json, sw.js, and icons folder) to the repository root. Do not upload diary data or personal photos.
3. In repository Settings > Pages, publish from the main branch and root folder. Wait for the Pages URL.
4. Open the HTTPS Pages URL in Chrome on your Android phone.
5. Tap Chrome menu (⋮) > Install app or Add to Home screen.
6. Open ARISE from the new icon. Try saving a sample diary entry and study session.

PHONE-ONLY NOTE
On GitHub's mobile site, use Add file / Upload files and select these individual files; uploading the ZIP itself does not publish the contents. If creating the icons folder in the web UI is awkward, upload the icons PNG files using the folder path shown by the upload flow.

This app is a personal prototype, not affiliated with Solo Leveling or any JEE testing body. It is not a replacement for official exam information.
